# -*- coding: utf-8 -*-

# module __init__

# Copyright (C) 2019 National Research Council Canada
# Author:  Harold Parks

# This file is part of MetroloPy.

# MetroloPy is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software 
# Foundation, either version 3 of the License, or (at your option) any later 
# version.

# MetroloPy is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more 
# details.

# You should have received a copy of the GNU General Public License along with 
# MetroloPy. If not, see <http://www.gnu.org/licenses/>.

from importlib.metadata import version
__version__ = version('metrolopy')

from .gummy import gummy,jummy
from .unit import Unit,Conversion,one,Quantity,QuantityArray,unit,MFraction
from .ummy import ummy,immy
from .nummy import nummy
from .budget import Budget
from .prefixedunit import PrefixedUnit,BinaryPrefixedUnit
from .nonlinearunit import NonlinearUnit,NonlinearConversion
from .offsetunit import OffsetUnit,OffsetConversion
from .logunit import LogUnit,LogConversion
from .functions import *
from .mean import *
from .fit import *
from .distributions import *
from .exceptions import *
from .printing import set_printer
from .unitutils import search_units,shadowed_units,convert,search_units_result
from .constant import (GummyConstant,JummyConstant,constant,search_constants,
                       shadowed_constants,search_constants_result)